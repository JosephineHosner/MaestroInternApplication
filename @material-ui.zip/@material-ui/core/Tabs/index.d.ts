export { default } from './Tabs';
export * from './Tabs';
