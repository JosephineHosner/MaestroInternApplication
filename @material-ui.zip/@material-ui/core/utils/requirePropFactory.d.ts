export default function requirePropFactory(componentNameInError: string): any;
