export default function ownerWindow(node: Node): Window;
