"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = unwrap;

function unwrap(component) {
  return component.Naked;
}